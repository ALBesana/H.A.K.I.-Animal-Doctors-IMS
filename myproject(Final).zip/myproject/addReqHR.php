<?php
// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "animal";

$conn = new mysqli($host, $username, $password, $database);

// Check if the connection failed
if ($conn->connect_error) {
    die(json_encode(["success" => false, "error" => "Database connection failed: " . $conn->connect_error]));
}

// Set JSON response header
header("Content-Type: application/json");

// Handle GET request (Dropdowns)
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (isset($_GET["type"]) && $_GET["type"] === "products") {
        $sql = "SELECT product_id, product_name FROM tbl_product";
    } else {
        $sql = "SELECT branch_id, branch_name FROM tbl_branch";
    }

    $result = $conn->query($sql);
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
    exit();
}

// Handle POST request (Insert Data)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    error_log("Received POST data: " . print_r($_POST, true));

    // Match JS field names
    $branch_id = $_POST["branch_id"] ?? null;
    $product_id = $_POST["product_id"] ?? null;
    $rd_quantity_requested = $_POST["quantity"] ?? null;
    $re_remarks = $_POST["remarks"] ?? "";

    // Validate required fields
    if (!$branch_id || !$product_id || !$rd_quantity_requested) {
        echo json_encode(["success" => false, "error" => "All fields are required!"]);
        exit();
    }

    // Insert into `tbl_requests_details`
    $stmt = $conn->prepare("INSERT INTO tbl_request_details (branch_id, product_id, rd_quantity_requested, re_remarks) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $branch_id, $product_id, $rd_quantity_requested, $re_remarks);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => "Database error: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
    exit();
}

$conn->close();
?>