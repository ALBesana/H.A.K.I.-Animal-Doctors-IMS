<?php
header('Content-Type: application/json');
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "animal"; // Change to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch product types from database
$sql = "SELECT product_type_name FROM tbl_product_type"; // Adjust table & column names
$result = $conn->query($sql);

$productTypes = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productTypes[] = $row;
    }
}

// Return JSON response
echo json_encode($productTypes);

$conn->close();
?>