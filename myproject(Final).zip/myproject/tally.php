<?php
include 'connection.php';

$sql = "SELECT 
            SUM(CASE WHEN status = 'approve' THEN 1 ELSE 0 END) AS approved,
            SUM(CASE WHEN status = 'reject' THEN 1 ELSE 0 END) AS rejected
        FROM deliveries";

$result = $conn->query($sql);
$data = $result->fetch_assoc();

echo json_encode($data);

$conn->close();
?>