<?php
include 'connection.php'; // Connect to database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $branch_name = $_POST["branch_name"];
    $status = $_POST["status"];

    // Update status in the database
    $sql = "UPDATE deliveries SET status = ? WHERE branch_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $status, $branch_name);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Delivery status updated successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error updating status"]);
    }

    $stmt->close();
    $conn->close();
}
?>