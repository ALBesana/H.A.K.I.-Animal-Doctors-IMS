<?php
$hashed_password = password_hash("pass", PASSWORD_DEFAULT);
echo "Hashed Password: " . $hashed_password;
?>