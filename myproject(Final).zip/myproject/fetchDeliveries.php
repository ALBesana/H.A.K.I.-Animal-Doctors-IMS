<?php
include 'connection.php';
header('Content-Type: application/json');

$sql = "SELECT DISTINCT deliveries_id FROM deliveries ORDER BY deliveries_id DESC";
$result = $conn->query($sql);

$deliveries = [];
while ($row = $result->fetch_assoc()) {
    $deliveries[] = $row;
}

echo json_encode($deliveries);
$conn->close();
?>