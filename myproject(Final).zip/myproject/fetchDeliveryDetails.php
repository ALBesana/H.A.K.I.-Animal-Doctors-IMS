<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

include 'connection.php';

if (!isset($_GET["deliveries_id"])) {
    echo json_encode(["success" => false, "error" => "Missing deliveries_id parameter"]);
    exit;
}

$deliveries_id = intval($_GET["deliveries_id"]);

if (!$conn) {
    echo json_encode(["success" => false, "error" => "Database connection failed"]);
    exit;
}

$sql = "SELECT deliveries_id, request_details_id, status, request_date FROM deliveries WHERE deliveries_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["success" => false, "error" => "SQL prepare failed: " . $conn->error]);
    exit;
}

$stmt->bind_param("i", $deliveries_id);

if (!$stmt->execute()) {
    echo json_encode(["success" => false, "error" => "SQL execution failed: " . $stmt->error]);
    exit;
}

$result = $stmt->get_result();
$deliveries = [];

while ($row = $result->fetch_assoc()) {
    $deliveries[] = $row;
}

if (empty($deliveries)) {
    echo json_encode(["success" => false, "error" => "No deliveries found for this ID"]);
} else {
    echo json_encode(["success" => true, "data" => $deliveries]);
}

$stmt->close();
$conn->close();
?>