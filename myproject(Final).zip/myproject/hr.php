<?php include 'check.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Animal Doctors Dashboard</title>
    <link rel="stylesheet" href="hr.CSS">
</head>
<body>
    <!-- Header Container -->
    <div class="header-container">
        <h1>Animal Doctors</h1>
    </div>
    
    <!-- Main Dashboard Container -->
    <div class="dashboard-container">
        <!-- HR Line -->
        <h1>HR</h1>

        <!-- Add Request, Pending Request, Transaction History Buttons -->
        <div class="button-row">
            <button class="dashboard-button" onclick="window.location.href='addReqHR.html'">Add Request</button>
            <button class="dashboard-button" onclick="window.location.href='viewPendingRequest.html'">View Requests</button>
            <button class="dashboard-button" onclick="window.location.href='transactionHistory.html'">Transaction History</button>
        </div>

        <!-- Product Stock and Delivery Buttons -->
        <div class="button-row">
            <button class="dashboard-button" onclick="window.location.href='deliveryHistory.html'">Delivery History</button>
            <button class="dashboard-button" onclick="window.location.href='deliveryHR.html'">Delivery</button>
        </div>
        <button onclick="history.back()">Back</button>
    </div>
</body>
</html>