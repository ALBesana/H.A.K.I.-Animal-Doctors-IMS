<?php
$host = "localhost";
$user = "root";  // Default XAMPP user
$password = "";  // Default XAMPP password (empty)
$database = "animal";  // Change to your actual database name

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from a table
$sql = "SELECT * FROM tbl_branch";  // Change 'users' to your table name
$result = $conn->query($sql);

$data = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Return data as JSON
echo json_encode($data);

$conn->close();
?>