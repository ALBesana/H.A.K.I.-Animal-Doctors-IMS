<?php
include 'connection.php'; // Ensure database connection

header('Content-Type: application/json');

$sql = "SELECT branch_name, status FROM deliveries";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
$conn->close();
?>