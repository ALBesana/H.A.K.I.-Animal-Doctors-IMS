<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

ob_clean(); // Prevent any extra output

include 'connection.php';

$response = ["success" => false];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    ob_clean(); // Prevent unexpected output

    $request_details_id = $_POST["request_details_id"] ?? null; // Change from 'branch' to 'request_details_id'
    $approval = $_POST["approval"] ?? null;

    if (!$request_details_id || !$approval) {
        echo json_encode(["success" => false, "error" => "Missing request ID or approval status"]);
        exit;
    }

    // Ensure `deliveries` table has `request_details_id` instead of `branch_name`
    $stmt = $conn->prepare("INSERT INTO deliveries (request_details_id, status) VALUES (?, ?) 
                            ON DUPLICATE KEY UPDATE status=?");
    $stmt->bind_param("iss", $request_details_id, $approval, $approval); // First param should be INT

    if ($stmt->execute()) {
        $response["success"] = true;
    } else {
        $response["error"] = "Database error: " . $stmt->error;
    }

    $stmt->close();
}

echo json_encode($response);
exit;
?>