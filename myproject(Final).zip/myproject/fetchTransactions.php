<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

include 'connection.php';

$sql = "
    SELECT 
        rd.request_details_id, 
        p.product_name, 
        rd.rd_quantity_requested, 
        p.price, 
        d.status
    FROM tbl_request_details rd
    JOIN tbl_product p ON rd.product_id = p.product_id
    LEFT JOIN deliveries d ON rd.request_details_id = d.request_details_id
";

$result = $conn->query($sql);

if (!$result) {
    echo json_encode(["success" => false, "error" => "Query error: " . $conn->error]);
    exit;
}

$transactions = [];

while ($row = $result->fetch_assoc()) {
    $transactions[] = $row;
}

echo json_encode($transactions);

$conn->close();
?>