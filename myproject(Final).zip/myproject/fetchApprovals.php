<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

include 'connection.php';

$sql = "SELECT approval_id FROM tbl_approval";
$result = $conn->query($sql);

$approvals = [];

while ($row = $result->fetch_assoc()) {
    $approvals[] = $row;
}

echo json_encode($approvals);
$conn->close();
?>