<?php
header("Content-Type: application/json");

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "animal";
$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// If no request_details_id is provided, return all request IDs
if (!isset($_GET["request_details_id"])) {
    $sql = "SELECT request_details_id FROM tbl_request_details";
    $result = $conn->query($sql);

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode($data); // ✅ Return an array of request IDs
    exit();
}

// If request_details_id is provided, fetch the request details
$request_details_id = (int)$_GET["request_details_id"];

$sql = "SELECT 
            r.request_details_id, 
            b.branch_name, 
            p.product_name, 
            r.rd_quantity_requested, 
            r.re_remarks 
        FROM tbl_request_details r
        LEFT JOIN tbl_branch b ON r.branch_id = b.branch_id
        LEFT JOIN tbl_product p ON r.product_id = p.product_id
        WHERE r.request_details_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $request_details_id);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

if (empty($data)) {
    echo json_encode(["success" => false, "error" => "No request details found for ID: " . $request_details_id]);
} else {
    echo json_encode($data);
}

$stmt->close();
$conn->close();
?>