<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "animal";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "error" => "Database connection failed: " . $conn->connect_error]));
}

header("Content-Type: application/json");

// Fetch only request IDs
$sql = "SELECT request_details_id FROM tbl_request_details ORDER BY request_details_id DESC";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
$conn->close();
?>